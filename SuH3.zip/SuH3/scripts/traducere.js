function googleTranslateElementInit() {
new google.translate.TranslateElement({ pageLanguage: 'ro', layout: google.translate.TranslateElement.FloatPosition.TOP_RIGHT }, 'google_translate_element');}